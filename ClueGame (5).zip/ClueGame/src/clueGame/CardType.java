/*
 * 
 * Authors: Demonna Wade and Erica Manzer 
 * 
 */

package clueGame;

public enum CardType {
	PERSON, WEAPON, ROOM; 
}
