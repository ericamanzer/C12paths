package clueGame;

public enum DoorDirection {
	UP, DOWN, RIGHT, LEFT, NONE;
}
