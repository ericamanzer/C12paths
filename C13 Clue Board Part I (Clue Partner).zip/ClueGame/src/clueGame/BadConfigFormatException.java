package clueGame;

public class BadConfigFormatException {
	// Instructions told to leave as skeleton and requires a constructor
	public BadConfigFormatException()
	{
		// empty constructor
	}
}
