/*
 * 
 * Authors: Demonna Wade and Erica Manzer 
 * 
 */

package clueGame;

public enum DoorDirection {
	UP, DOWN, RIGHT, LEFT, NONE;
}
