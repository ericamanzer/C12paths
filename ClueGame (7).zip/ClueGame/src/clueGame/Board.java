/*
 * 
 * Authors: Demonna Wade and Erica Manzer 
 * 
 */

package clueGame;
import java.util.*;
import java.io.*;
import java.lang.*;
import clueGame.BoardCell;
import java.awt.Point;
import java.awt.BorderLayout;
import java.awt.Color;
import java.lang.reflect.Field;
import javax.swing.JPanel;   // library for JPanel
import java.awt.*;    // library for Graphics 
import javax.swing.*;

// converted the Board class into a subclass of JPanel
public class Board extends JPanel {
	// Variables:
	public static final int MAX_BOARD_SIZE = 50;
	private int numRows;
	private int numColumns;
	private Solution answerKey;
	private BoardCell[][] board;
	private Map<Character, String> legend;
	static private Map<BoardCell, Set<BoardCell>> adjMatrix;
	private Set<BoardCell> targets;
	private Set<BoardCell> visited;
	// Set that would hold the computer player
	private Set<ComputerPlayer> computerPlayers;
	// Set that would hold the human player
	private Set<HumanPlayer> humanPlayer;
	private Set<String> weapons; 
	private Set<String> rooms;
	private Set<Card> key; 
	private Set<Card> deck;
	private Set<Card> roomPile;
	private Set<Card> peoplePile;
	private Set<Card> weaponsPile;
	private String boardConfigFile;
	private String roomConfigFile;
	private String peopleConfigFile;
	private String weaponsConfigFile; 
	ArrayList<Card> possibleCards = new ArrayList<Card>();
	public ArrayList<Card> possiblePeople = new ArrayList<Card>();  
	public ArrayList<Card> possibleWeapons = new ArrayList<Card>(); 
	public ArrayList<Card> possibleRooms = new ArrayList<Card>();
	ArrayList<Player> player = new ArrayList<Player>();
	ArrayList<Point> roomNames = new ArrayList<Point>();
	// Functions:
	//NOTE: Singleton pattern 
	private static Board theInstance = new Board();
	private Board() 
	{
		JPanel panel = new JPanel();
		JLabel name = new JLabel("Clue Game Board");
		panel.add(name);
		add(panel, BorderLayout.CENTER);
		
	}
	public static Board getInstance() 
	{
		return theInstance;
	}

	public void setConfigFiles(String boardFile, String roomFile)
	{
		boardConfigFile = boardFile;
		roomConfigFile = roomFile;
	}
	public void setWeaponsConfigFile(String weaponsFile)
	{
		weaponsConfigFile = weaponsFile;
	}
	public void setPeopleConfigFile (String peopleFile)
	{
		peopleConfigFile = peopleFile;
	}

	public void loadRoomConfig() { 
		//TODO load room config file
		int count = 0;
		File file = new File(roomConfigFile);
		Scanner scan = null;
		try 
		{

			scan = new Scanner(file);
			while (scan.hasNextLine())
			{
				String line = scan.nextLine();
				String[] lineArray = line.split(",");
				String letterString = lineArray[0];
				int x = Integer.parseInt(lineArray[3]);
				int y = Integer.parseInt(lineArray[4]);
				Point pixel = new Point (x * 32 + 50, y * 32 + 50);
				roomNames.add(pixel);
				char letter = letterString.charAt(0);
				legend.put(letter, lineArray[1]);
				//System.out.println(lineArray[2]);
				//String card = lineArray[1]; 
				rooms.add(lineArray[1]);

				// adding to the roomPile

				if (count > 1)
				{
					Card room = new Card(lineArray[1], CardType.ROOM);
					roomPile.add(room);
					//System.out.println("Adding to roomPile");
				}
				count ++;
			}

		}
		catch (FileNotFoundException e)
		{
			System.out.println(e.getMessage());
			System.out.println
			("Unable to open file " + roomConfigFile + ".");
		}
		catch (NullPointerException a)
		{
			BadConfigFormatException b = new BadConfigFormatException(a.getLocalizedMessage());
			b.getMessage();
		}
		finally
		{
			scan.close();
		}
		System.out.println("Set<String> room size: " + rooms.size());
	}


	public void loadBoardConfig() {
		//TODO load board config file
		int x = 0, y = 0;
		File file = new File (boardConfigFile);
		Scanner scan = null;
		try
		{
			scan = new Scanner(file);
			while (scan.hasNextLine())
			{
				String line = scan.nextLine(); 
				String[] array = line.split(",");
				this.numColumns = array.length;
				for (y = 0; y < numColumns; y++)
				{
					if (array[y].length() == 1)
					{
						char letter = array[y].charAt(0);
						BoardCell cell = new BoardCell(x, y, letter, DoorDirection.NONE);
						board[x][y] = cell;
					}
					if (array[y].length() == 2)
					{
						char letter = array[y].charAt(0);
						char dir = array[y].charAt(1);
						BoardCell cell = new BoardCell();
						if (dir == 'R' || dir == 'r') cell = new BoardCell(x, y, letter, DoorDirection.RIGHT);
						if (dir == 'L'|| dir == 'l') cell = new BoardCell(x, y, letter, DoorDirection.LEFT);
						if (dir == 'U' || dir == 'u') cell = new BoardCell(x, y, letter, DoorDirection.UP);
						if (dir == 'D' || dir == 'd') cell = new BoardCell(x, y, letter, DoorDirection.DOWN);
						if (dir == 'N' || dir == 'n') cell = new BoardCell(x, y, letter, DoorDirection.NONE);
						board[x][y] = cell;
					}
				}
				x++;
			}
			this.numRows = x;
		}
		catch (FileNotFoundException e)
		{
			System.out.println(e.getMessage());
			System.out.println
			("Unable to open/load " + boardConfigFile + " .");

		}
		catch (NullPointerException a) 
		{
			BadConfigFormatException b = new BadConfigFormatException(a.getMessage()); 
			System.out.println(b.getMessage());
		}
		finally
		{
			scan.close();
		}
		
	}

	public void loadPeopleConfig()
	{
		//TODO load People config file
		File file = new File(peopleConfigFile);
		Scanner scan = null;
		int count = 0;
		try 
		{
			scan = new Scanner(file);
			while (scan.hasNextLine())
			{
				String line = scan.nextLine();
				String[] lineArray = line.split(",");
				if (count <= 0)
				{
					HumanPlayer human = new HumanPlayer(lineArray[0], lineArray[1], Integer.parseInt(lineArray[2]), Integer.parseInt(lineArray[3]));
					humanPlayer.add(human);
				}
				else
				{
					ComputerPlayer computer = new ComputerPlayer(lineArray[0], lineArray[1], Integer.parseInt(lineArray[2]), Integer.parseInt(lineArray[3]));
					computerPlayers.add(computer);
				}
				count ++;

				// add players to larger deck
				Card people = new Card (lineArray[0], CardType.PERSON);
				peoplePile.add(people);
			}

		}
		catch (FileNotFoundException e)
		{
			System.out.println(e.getMessage());
			System.out.println
			("Unable to open file " + roomConfigFile + ".");
		}
		catch (NullPointerException a)
		{
			BadConfigFormatException b = new BadConfigFormatException(a.getLocalizedMessage());
			b.getMessage();
		}
		finally
		{
			scan.close();
		}
	}

	public void loadWeaponConfig() { 
		//TODO load room config file
		File file = new File(weaponsConfigFile);
		Scanner scan = null;
		try 
		{
			scan = new Scanner(file);
			while (scan.hasNextLine())
			{
				String line = scan.nextLine();
				//weapons.add(line);

				// add the weapons to the deck
				Card weapon = new Card (line, CardType.WEAPON);
				weaponsPile.add(weapon);
			}

		}
		catch (FileNotFoundException e)
		{
			System.out.println(e.getMessage());
			System.out.println
			("Unable to open file " + roomConfigFile + ".");
		}
		catch (NullPointerException a)
		{
			BadConfigFormatException b = new BadConfigFormatException(a.getLocalizedMessage());
			b.getMessage();
		}
		finally
		{
			scan.close();
		}
	}


	public void initialize() {
		legend = new HashMap<Character, String>();
		targets = new HashSet<BoardCell>();
		board = new BoardCell[MAX_BOARD_SIZE][MAX_BOARD_SIZE];
		visited = new HashSet<BoardCell>();
		adjMatrix = new HashMap<BoardCell, Set<BoardCell>>();
		answerKey = new Solution();
		computerPlayers = new HashSet<ComputerPlayer>();
		humanPlayer = new HashSet<HumanPlayer>();
		deck = new HashSet<Card>();
		key = new HashSet<Card>();
		roomPile = new HashSet<Card>();
		peoplePile = new HashSet<Card>();
		weaponsPile = new HashSet<Card>();
		rooms = new HashSet<String>();

		//NOTE: used to load configuration files
		loadRoomConfig();
		loadPeopleConfig();
		loadWeaponConfig();
		loadBoardConfig();
		//find adjacencies
		calcAdjacencies();

		//deal deck
		dealDeck();

	}

	public void calcAdjacencies() 
	{ 

		// calculating the adjacency
		for (int i = 0; i < numRows; i++)  // i = x
		{
			for (int j = 0; j < numColumns; j++)  // j = y
			{
				Set<BoardCell> adj = new HashSet<BoardCell>();
				if ( i - 1 >= 0)
				{
					//checking if it is a walkway possibility
					if (board[i - 1][j].isWalkway()){
						switch (board[i][j].getDoorDirection()){
						case UP:
							adj.add(board[i - 1][j]);
							break;
						case NONE:
							adj.add(board[i - 1][j]);
							break;
						default:
							break;
						}
					}

					//checking if it is a door with the correct direction
					if (board[i - 1][j].isDoorway() && board[i - 1][j].getDoorDirection() == DoorDirection.DOWN)
					{
						adj.add(board[i - 1][j]);
					}

					//checking if it is a room with DoorDirection.NONE
					if (board[i][j].isRoom() && board[i][j].getDoorDirection() == DoorDirection.NONE)
					{
						if ( adj.contains(board[i - 1][j]))
						{
							adj.remove(board[i - 1][j]);
						}
					}
				}
				if (i + 1 < numRows)
				{
					//checking if it is a walkway possibility
					if (board[i + 1][j].isWalkway()){
						switch (board[i][j].getDoorDirection()){
						case DOWN:
							adj.add(board[i + 1][j]);
							break;
						case NONE:
							adj.add(board[i + 1][j]);
							break;
						default:
							break;
						}
					}
					//checking if it is a door with the correct direction
					if (board[i + 1][j].isDoorway() && board[i + 1][j].getDoorDirection() == DoorDirection.UP)
					{
						adj.add(board[i + 1][j]);
					}

					//checking if it is a room with DoorDirection.NONE
					if (board[i][j].isRoom() && board[i][j].getDoorDirection() == DoorDirection.NONE)
					{
						if ( adj.contains(board[i + 1][j]))
						{
							adj.remove(board[i + 1][j]);
						}
					}
				}
				if (j - 1 >= 0)
				{
					//checking if it is a walkway possibility
					if (board[i][j - 1].isWalkway()){
						//if (board[i][j] == board[11][6]) System.out.println("HERE j - 1");
						switch (board[i][j].getDoorDirection()){
						case LEFT:
							adj.add(board[i][j - 1]);
							break;
						case NONE:
							adj.add(board[i][j - 1]);
							break;
						default:
							break;
						}
					}
					//checking if it is a door with the correct direction
					if (board[i][j - 1].isDoorway() && board[i][j - 1].getDoorDirection() == DoorDirection.RIGHT)
					{
						adj.add(board[i][j - 1]);
					}

					//checking if it is a room with DoorDirection.NONE
					if (board[i][j].isRoom() && board[i][j].getDoorDirection() == DoorDirection.NONE)
					{
						if ( adj.contains(board[i][j - 1]))
						{
							adj.remove(board[i][j - 1]);
						}
					}
				}
				if (j + 1 < numColumns)
				{
					//checking if it is a walkway possibility
					if (board[i][j + 1].isWalkway()){
						switch (board[i][j].getDoorDirection()){
						case RIGHT:
							adj.add(board[i][j + 1]);
							break;
						case NONE:
							adj.add(board[i][j + 1]);
							break;
						default:
							break;
						}
					}
					//checking if it is a door with the correct direction
					if (board[i][j + 1].isDoorway() && board[i][j + 1].getDoorDirection() == DoorDirection.LEFT)
					{
						adj.add(board[i][j + 1]);
					}

					//checking if it is a room with DoorDirection.NONE
					if (board[i][j].isRoom() && board[i][j].getDoorDirection() == DoorDirection.NONE)
					{
						if ( adj.contains(board[i][j + 1]))
						{
							adj.remove(board[i][j + 1]);
						}
					}
				}


				adjMatrix.put(board[i][j], new HashSet<BoardCell>(adj));
				adj.clear();
			}
		}
	}

	public void calcTargets(int row, int col, int pathlength) 
	{ 
		// set visited list to empty
		visited.clear();
		// initially set targets to an empty list
		targets.clear();
		// add start location to the visited list
		visited.add(board[row][col]);

		find(row, col, pathlength);
	}

	public void find (int row, int col, int pathLength)
	{
		Set<BoardCell> adjCell = new HashSet<BoardCell>();
		if (adjMatrix.containsKey(board[row][col]))
		{
			adjCell = adjMatrix.get(board[row][col]);
			for (BoardCell test: adjCell)
			{

				if (test.isDoorway() && !visited.contains(test))
				{
					targets.add(test);
				}

				if (visited.contains(test))
				{
					continue; 
				}
				else 
				{
					visited.add(test);
				}
				if (pathLength == 1)
				{
					targets.add(test);
				}
				else
				{
					find(test.getCol(), test.getRow(), pathLength - 1);
				}
				visited.remove(test);

			}

		}
		else 
		{
			System.out.println("This key does not exist in the adjMatrix");
		}
	}



	//NOTE: Getters {
	public Map<Character, String> getLegend()
	{
		return legend;
	}
	public int getNumRows()
	{
		// correct way
		return numRows;
	}
	public int getNumColumns()
	{
		// correct way
		return numColumns;
	}
	public BoardCell getCellAt(int row, int col)
	{
		return board[row][col];
	}
	public BoardCell[][] getBoard()
	{
		return board;
	}
	public Set<BoardCell> getAdjList( int row, int col)
	{
		BoardCell cell = new BoardCell();
		cell = getCellAt(row, col);
		Set<BoardCell> found = new HashSet<BoardCell>();
		found = adjMatrix.get(cell);
		return found;
	}

	public Set<BoardCell> getTargets()
	{
		return targets;
	}

	public void dealDeck() { 

		
		possibleCards.clear(); 
		possiblePeople.clear();
		possibleWeapons.clear(); 
		possibleRooms.clear(); 		
		
		// Loads the deck and temporary ArrayLists with every card read into program 
		for (Card temp: peoplePile) {
			deck.add(temp); 
			possiblePeople.add(temp); 
		}
		for (Card temp: weaponsPile) { 
			deck.add(temp); 
			possibleWeapons.add(temp); 
		}
		for(Card temp: roomPile) {
			deck.add(temp); 
			possibleRooms.add(temp);
		}


		Random rand = new Random(); 
		// Get random person for murderer 
		int r = rand.nextInt(possiblePeople.size()); 
		key.add(possiblePeople.get(r)); 
		deck.remove(possiblePeople.get(r)); 
		answerKey.setAnswerKeyPerson(possiblePeople.get(r).getCardname());
		// Get random weapon for murder weapon 
		r = rand.nextInt(possibleWeapons.size()); 
		key.add(possibleWeapons.get(r)); 
		deck.remove(possibleWeapons.get(r));
		answerKey.setAnswerKeyWeapon(possibleWeapons.get(r).getCardname());
		// Get random room for crime scene 
		key.add(possibleRooms.get(r)); 
		deck.remove(possibleRooms.get(r)); 
		answerKey.setAnswerKeyRoom(possiblePeople.get(r).getCardname());
		// Loads remaining deck values into the temp ArrayList 
		for (Card temp: deck) {
			possibleCards.add(temp);  
		}
		//System.out.println(possibleCards.size());


		for(HumanPlayer person: humanPlayer) {
			for (int j = 0; j < 3; j++) { 
				r = rand.nextInt(possibleCards.size());
				person.addCard(possibleCards.get(r));
				deck.remove(possibleCards.get(r)); 
				possibleCards.remove(r); 	
			}
		}

		for(ComputerPlayer person: computerPlayers) {
			for (int j = 0; j < 3; j++) { 
				r = rand.nextInt(possibleCards.size());
				person.addCard(possibleCards.get(r));
				deck.remove(possibleCards.get(r)); 
				possibleCards.remove(r); 	
			}
		}




	}



	/*
	public void selectAnswer() { 

	}


	 */ 


	public boolean checkAccusation(Solution accusation) {

		String p, w, r;   
		p = accusation.getPerson(); 
		w = accusation.getWeapon(); 
		r = accusation.getRoom(); 

		// check person 
		if (!answerKey.getPerson().equals(p)) {
			return false; 
		}
		// check weapon 
		if (!answerKey.getWeapon().equals(w)) {
			return false; 
		}
		// check room 
		if (!answerKey.getRoom().equals(r)) {
			return false; 
		}

		// If no differences exist then returns true 
		return true;
	}

	public Card handleSuggestion(ComputerPlayer computerPlayer) {

		ArrayList<Card> possibleSuggestions = new ArrayList<Card>(); 

		for(ComputerPlayer tempPlayer: computerPlayers) {
			if (tempPlayer == computerPlayer) {
				continue;  
			}
			for(Card tempCard: tempPlayer.getMyCards()) {
				possibleSuggestions.add(tempCard); 
			}
		}

		int row = computerPlayer.getCurrentRow(); 
		int col = computerPlayer.getCurrentColumn();
		
		computerPlayer.createSuggestion(board[col][row], possiblePeople, possibleWeapons, rooms, computerPlayer); 
		
		ArrayList<Card> foundCards = new ArrayList<Card>(); 
		
		for(ComputerPlayer tempPlayer: computerPlayers) {
			if (tempPlayer == computerPlayer) {
				continue;  
			}
			else { 
				Card temp = tempPlayer.disproveSuggestion(computerPlayer.createdSoln); 
				foundCards.add(temp); 
			}
		}


		Random rand = new Random(); 
		int location = rand.nextInt(foundCards.size()); 

		if (foundCards.size() == 0) {
			return null;
		}
		else { 
			computerPlayer.addSeen(foundCards.get(location));
			return foundCards.get(location); 
		}
		
	}
	
	// paintComponent method for drawing the board. It is drawn in an object-oriented manner
	// use an object-oriented approach that has each BoardCell object draw itself.
	
	public void paintComponent ( Graphics g)
	{
		super.paintComponent(g);
		// TODO call each BoardCell  object to draw itself
		// 	the draw method from BoardCell class will be called
		
		for ( int i = 0; i < 22; i++)
		{
			for ( int j = 0; j < 23; j++)
			{
				getCellAt(i, j).draw(g);
			}
		}
		
		for ( ComputerPlayer comp: computerPlayers)
		{
			int x = comp.getCurrentRow();
			int y = comp.getCurrentColumn();
			Color color = comp.getColor();
			g.setColor(color);
			Point pixel = new Point( x * 32 + 50, y * 32 + 50);
			g.fillOval(pixel.x, pixel.y, 30, 30);
		}
		
		for ( HumanPlayer human: humanPlayer)
		{
			int x = human.getCurrentRow();
			int y = human.getCurrentColumn();
			Color color2 = human.getColor();
			g.setColor(color2);
			Point pixel = new Point( x * 32 + 50, y * 32 + 50);
			g.fillOval(pixel.x, pixel.y, 30, 30);
		}
		
		ArrayList<String> names = new ArrayList<String>();
		names.add("Paths");
		names.add("Kafadar");
		names.add("Marquez");
		names.add("Hill Hall");
		names.add("Guggenheim");
		names.add("Brown");
		names.add("Randall");
		names.add("Alderson");
		names.add("Coolbaugh");
		names.add("Elm");
		names.add("Weaver");
		
		for ( int i = 0; i < names.size(); i++)
		{
			if ( i == 0) continue;
			Point pixel = new Point();
			pixel = roomNames.get(i);
			String room = names.get(i);
			g.setColor(Color.BLACK);
			g.setFont(new Font("Calibri", Font.PLAIN, 24));
			g.drawString(room, pixel.x, pixel.y);
		}
		
	
		
	}

	// Getter for computerPlayers 
	// @param no parameter 
	// @return computerPlayers a set of player that are not the player 1 
	public Set<ComputerPlayer> getComputerPlayers() {
		return computerPlayers;
	}

	// Getter for humanPlayers	
	// @param no parameter 
	// @return humanPlayer a set of size one that only contains player 1 
	public Set<HumanPlayer> getHumanPlayer() {
		return humanPlayer;
	}

	// Getter for weapons 
	// @param no parameter 
	// @return weapons a set of Strings that represent each of the weapons possible 
	public Set<String> getWeapons() {
		return weapons;
	}

	// Getter for rooms 
	// @param no parameter 
	// @return rooms a set of strings that represent each of the rooms possible 
	public Set<String> getRooms() {
		return rooms;
	}

	// Getter for deck
	// @param no parameter 
	// @return deck a set of cards that represent each of the people, weapons, and rooms 
	public Set<Card> getDeck() {
		return deck;
	}

	// Getter for key 
	// @param no parameter 
	// @return key a set of card, one of each type of card, that represent the murderer, the killing weapon, and the room where the murder took place 
	public Set<Card> getKey() {
		return key; 
	}

	// Getter for roomPile
	// @param no parameter
	// @return roomPile the set of room cards
	public Set<Card> getRoomPile()
	{
		return roomPile;
	}

	// Getter for weaponsPile
	// @param no parameter
	// @return weaponsPile the set of weapons card
	public Set<Card> getWeaponsPile()
	{
		return weaponsPile;
	}

	// Getter for peoplePile
	// @param no parameter
	// @return peoplePile the set of people cards
	public Set<Card> getPeoplePile()
	{
		return peoplePile;
	}


	// Getter for getAnswerKey() 
	// @param no parameter 
	// @return answerKey 
	public Solution getAnswerKey() {
		return answerKey; 
	}
	
	public void clearPossiblePeople() { 
		possiblePeople.clear();
	} 
	
	public void addPossiblePeople(Card card) { 
		possiblePeople.add(card); 
	}
	
	public void clearPossibleWeapons() { 
		possibleWeapons.clear();
	}
	
	public void addPossibleWeapons(Card card) { 
		possibleWeapons.add(card); 
	}
	
	public void clearPossibleRooms() { 
		rooms.clear();
	}
	
	public void addPossibleRooms(String room) { 
		rooms.add(room); 
	}
	
	public void setPossiblePeople(ArrayList<Card> possiblePeople) { 
		possiblePeople = this.possiblePeople; 
	}
	
	public void setPossibleWeapons(ArrayList<Card> possibleWeapons) { 
		possibleWeapons = this.possibleWeapons; 
	}
	
	public void setPossibleRooms(Set<String> rooms) { 
		rooms = this.rooms; 
	}
	
}






