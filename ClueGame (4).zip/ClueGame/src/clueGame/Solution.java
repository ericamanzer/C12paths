package clueGame;

public class Solution {

	String person, room, weapon; 
	
}
